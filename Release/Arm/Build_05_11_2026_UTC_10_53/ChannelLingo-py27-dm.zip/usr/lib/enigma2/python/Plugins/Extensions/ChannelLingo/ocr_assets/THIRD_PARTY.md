# ChannelLingo OCR - component attribution

ChannelLingo OCR is the name of the ChannelLingo integration, asset packaging and
runtime adapter. It is not a claim of authorship of the underlying recognition
engine or trained language data. No original compiled subtitle-plugin extension
is used by this adapter.

## Native recognition engine

Tesseract OCR, https://github.com/tesseract-ocr/tesseract

Licensed under the Apache License, Version 2.0; see licenses/Apache-2.0.txt.
Both native executables are Tesseract 5.5.3 built from its upstream source (see the
two source-built editions below), losslessly compressed into runtime/<arch>/core.clx.
Compression and branding do not make it a new engine. Before 2026-10-28 the ARMv7
runtime was a supplied ready-made executable of unestablished origin, linked with
glibc; it was replaced and a copy is kept outside the plugin in .development/backups/.

## Language data

Tesseract language data, https://github.com/tesseract-ocr/tessdata and
https://github.com/tesseract-ocr/tessdata_fast, Apache License, Version 2.0.

All 23 models came from the user-supplied OCR directory. The supplied manifest
did not document every model's upstream revision. No unverified revision is
invented here. The exact supplied bytes are preserved and recorded by SHA256.
models/*.clm are losslessly compressed copies, not newly trained models.

## Redistribution

Both runtimes are built from upstream source by this project, so their sources
and build options are known (aarch64-build.json, armv7l-build.json). The language
models were supplied without a record of their upstream revision (see above).
This file and the Apache license are not a legal certification that every
notice has been collected; check them before a public release.

## Changes in this edition

2026-10-28: new ChannelLingo adapter, compressed asset layout, digest verification,
lazy per-language extraction, bounded cancellation, diagnostics and interface
branding. The reference OCR folder and legacy assets have not been deleted.


## AArch64 source-built edition

The AArch64 runtime was freshly cross-built from official Tesseract 5.5.3 and
Leptonica 1.87.0 sources downloaded from their upstream repositories, with the
official checksum-verified Zig 0.15.2 toolchain. It uses musl, libc++ and related
compiler runtime code. Matching notices are in licenses/AArch64-*.txt.
No previously supplied or locally archived AArch64 OCR executable or library
was used in the distributed binary. See aarch64-build.json for source URLs and
digests, and aarch64-audit.json for the actual ELF metadata.


## ARMv7 source-built edition

The ARMv7 runtime was cross-built the same way (tools/build_armv7l_ocr.py): official
Tesseract 5.5.3 and Leptonica 1.87.0 sources, the checksum-verified Zig 0.15.2
toolchain, target arm-linux.3.14-musleabihf (32-bit hard-float), CPU cortex_a9
(ARMv7-A with VFP and NEON), static, LSTM engine only. It uses the same musl,
libc++ and compiler runtime code, so the same notices in licenses/AArch64-*.txt
apply (the prefix is only the name they were first saved under). Source URLs and
digests: armv7l-build.json; ELF metadata: armv7l-audit.json.

Neither runtime has been run on a receiver by this project (native_inference_tested
is false in both records). Run tools/check_ocr.py --probe on the receiver.
