# -*- coding: utf-8 -*-
from ._catalog import LANGUAGES, set_language, get_language, tr
