ChannelLingo by iet5 - universal package

Copy this whole folder to the receiver (for example into /tmp), then run, as root:

    sh /tmp/ChannelLingo-universal/install.sh

It finds which Python Enigma2 runs and on which processor, picks the matching build and installs it as the
single package of that build would be. "sh install.sh --check" only says which build it would pick.
Your keys and settings in /etc/enigma2 are not touched; the old plugin folder is kept in /home/root.

To uninstall, run as root:

    sh /tmp/ChannelLingo-universal/uninstall.sh

Use --check to preview. The plugin is moved to a unique ChannelLingo.uninstalled-* backup in /home/root;
settings, keys and earlier backups are kept. A running Enigma2 is restarted automatically.

Builds in this package:
py27-dm              Python 2.7-ucs2  ARM 32-bit hard-float
py27ucs2-aarch64     Python 2.7-ucs2  ARM 64-bit
py27ucs4-aarch64     Python 2.7       ARM 64-bit
py27ucs4-armv7l      Python 2.7       ARM 32-bit hard-float
py314-aarch64        Python 3.14      ARM 64-bit
py314-dm             Python 3.14      ARM 32-bit hard-float

A build for another Python or processor is not here: the installer says so and installs nothing.
Receiver integration has NOT been tested on physical hardware for every build above.
