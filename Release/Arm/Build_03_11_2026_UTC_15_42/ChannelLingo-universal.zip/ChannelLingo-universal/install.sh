#!/bin/sh
# ChannelLingo by iet5 - installer of the universal package.
# It finds which Python Enigma2 runs and on which processor, takes the build that matches from this folder and installs
# it exactly as the single package of that build would be. Nothing outside the plugin folder is changed (your keys and
# settings in /etc/enigma2 stay); the old plugin folder is kept in /home/root.
#
#   sh install.sh            install the build that matches this receiver
#   sh install.sh --check    only say which build would be installed
#
# Tests only: CHANNELLINGO_ROOT=<folder> installs under <folder> instead of /, CHANNELLINGO_PYTHON=<interpreter> names the
# interpreter to ask, CHANNELLINGO_VARIANT=<name> forces a build.
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=${CHANNELLINGO_ROOT:-}
CHECK=0
[ "${1:-}" = "--check" ] && CHECK=1

say() { printf '%s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

# The Python that Enigma2 itself is linked to (the receiver may have another one too), else the first one found.
find_python() {
    if [ -n "${CHANNELLINGO_PYTHON:-}" ]; then printf '%s\n' "$CHANNELLINGO_PYTHON"; return; fi
    want=""
    if [ -r "$ROOT/usr/bin/enigma2" ]; then
        want=$(grep -a -o 'libpython[0-9][0-9]*\.[0-9][0-9]*' "$ROOT/usr/bin/enigma2" 2>/dev/null | head -n 1 | sed 's/libpython//')
    fi
    if [ -n "$want" ]; then
        for candidate in "python$want" python3 python python2; do
            command -v "$candidate" >/dev/null 2>&1 || continue
            have=$("$candidate" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null) || continue
            [ "$have" = "$want" ] && { printf '%s\n' "$candidate"; return; }
        done
    fi
    for candidate in python3 python python2; do
        command -v "$candidate" >/dev/null 2>&1 && { printf '%s\n' "$candidate"; return; }
    done
}

PY=$(find_python)
[ -n "$PY" ] || die "no Python found on this receiver"
FACTS=$("$PY" -c 'import platform, struct, sys
print("version=%d.%d" % sys.version_info[:2])
print("bits=%d" % (struct.calcsize("P") * 8))
print("machine=%s" % platform.machine().lower())
print("unicode=%s" % ("ucs2" if sys.maxunicode == 65535 else "ucs4"))' 2>/dev/null) || die "cannot run $PY"
fact() { printf '%s\n' "$FACTS" | sed -n "s/^$1=//p" | head -n 1; }
VER=$(fact version); BITS=$(fact bits); MACHINE=$(fact machine); UNI=$(fact unicode)
[ -n "$VER" ] && [ -n "$BITS" ] && [ -n "$MACHINE" ] || die "could not read the facts of $PY"
case "$VER" in 3.*) UNI="-" ;; esac
say "This receiver: Python $VER ($UNI), ${BITS}-bit, processor $MACHINE."

# ARM and (where this package has it) 32-bit MIPS. A 32-bit Python on a 64-bit ARM kernel may report armv8l or
# aarch64: the pointer size tells it from a real 64-bit one.
case "$BITS:$MACHINE" in
    32:armv7l|32:armv7|32:arm|32:armv8l|32:aarch64|32:arm64) ARCH=armv7l ;;
    64:aarch64|64:arm64) ARCH=aarch64 ;;
    32:mipsel|32:mips) ARCH=mipsel ;;
    *) die "this processor ($MACHINE, ${BITS}-bit Python) is not one this package is built for (ARM 32-bit and 64-bit, MIPS 32-bit little-endian)." ;;
esac

VARIANT=${CHANNELLINGO_VARIANT:-}
if [ -z "$VARIANT" ]; then
    case "$VER/$BITS/$UNI/$ARCH" in
        2.7/32/ucs2/armv7l) VARIANT=py27-dm ;;
        2.7/64/ucs2/aarch64) VARIANT=py27ucs2-aarch64 ;;
        2.7/64/ucs4/aarch64) VARIANT=py27ucs4-aarch64 ;;
        2.7/32/ucs4/armv7l) VARIANT=py27ucs4-armv7l ;;
        3.14/64/-/aarch64) VARIANT=py314-aarch64 ;;
        3.14/32/-/armv7l) VARIANT=py314-dm ;;
        *) VARIANT="" ;;
    esac
fi
if [ -z "$VARIANT" ] || [ ! -d "$HERE/variants/$VARIANT" ]; then
    say "No build in this package for Python $VER ($UNI), ${BITS}-bit. The builds here:"
    for found in "$HERE"/variants/*; do say "  $(basename "$found")"; done
    die "nothing was installed."
fi
say "Build chosen: $VARIANT"
[ "$CHECK" = "1" ] && { say "(--check: nothing was installed.)"; exit 0; }

EXT="$ROOT/usr/lib/enigma2/python/Plugins/Extensions"
PLUGIN="$EXT/ChannelLingo"
SHARED="$HERE/resources/usr/lib/enigma2/python/Plugins/Extensions/ChannelLingo"
OWN="$HERE/variants/$VARIANT/usr/lib/enigma2/python/Plugins/Extensions/ChannelLingo"
[ -d "$SHARED" ] && [ -d "$OWN" ] || die "this package is incomplete (a folder is missing)."

# The files must be what the builder wrote: a bad copy to the receiver is found here, not by Enigma2.
if command -v sha256sum >/dev/null 2>&1 && [ -r "$HERE/SHA256SUMS" ]; then
    LIST="${TMPDIR:-/tmp}/channellingo-sums-$$"
    grep -e ' resources/' -e " variants/$VARIANT/" "$HERE/SHA256SUMS" > "$LIST"
    (cd "$HERE" && sha256sum -c "$LIST" >/dev/null 2>&1) || { rm -f "$LIST"; die "a file of this package is damaged or missing: copy the package again."; }
    rm -f "$LIST"
    say "Files checked."
else
    say "(sha256sum not available: the files were not checked.)"
fi

mkdir -p "$EXT" || die "cannot write $EXT"
STAGE="$EXT/.channellingo-stage-$$"
rm -rf "$STAGE"
mkdir -p "$STAGE" || die "cannot write $STAGE"
cp -R "$SHARED/." "$STAGE/" && cp -R "$OWN/." "$STAGE/" || { rm -rf "$STAGE"; die "could not copy the files."; }
[ -f "$STAGE/plugin.py" ] && [ -f "$STAGE/ver.txt" ] || { rm -rf "$STAGE"; die "the installed copy is incomplete."; }

BACKUP=""
if [ -e "$PLUGIN" ]; then
    mkdir -p "$ROOT/home/root"
    BACKUP="$ROOT/home/root/ChannelLingo.backup-$(date +%Y%m%d-%H%M%S)"
    mv "$PLUGIN" "$BACKUP" || { rm -rf "$STAGE"; die "cannot move the old plugin folder away."; }
fi
if ! mv "$STAGE" "$PLUGIN"; then
    [ -n "$BACKUP" ] && mv "$BACKUP" "$PLUGIN"
    rm -rf "$STAGE"
    die "could not put the new plugin in place; the old one was put back."
fi
say "Installed: $VARIANT -> $PLUGIN"
[ -n "$BACKUP" ] && say "The old plugin folder is kept in $BACKUP"
say "Now restart Enigma2 (or restart the receiver)."
