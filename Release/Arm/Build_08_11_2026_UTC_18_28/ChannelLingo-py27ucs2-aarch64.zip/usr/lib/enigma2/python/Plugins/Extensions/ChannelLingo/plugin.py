# -*- coding: utf-8 -*-
# ChannelLingo by iet5. Native distribution entry point.
import platform as _platform
import struct as _struct
import sys as _sys
if _sys.version_info[:2] != (2, 7):
    raise ImportError('ChannelLingo requires CPython 2.7; install the matching build.')
if getattr(_sys, 'abiflags', '') or hasattr(_sys, 'gettotalrefcount'):
    raise ImportError('ChannelLingo requires a standard, GIL-enabled release Python build.')
_machine, _bits = _platform.machine().lower(), _struct.calcsize('P') * 8
if _machine not in ('aarch64', 'arm64') or _bits != 64:
    # Say what was found: "wrong architecture" alone does not tell a 64-bit receiver from a 32-bit one.
    raise ImportError('ChannelLingo: wrong receiver architecture (this receiver: %s, %d-bit Python; this build is for '
                      'aarch64, 64-bit); install the matching build.' % (_machine, _bits))
if _sys.maxunicode != 65535:
    raise ImportError('ChannelLingo requires Python 2.7 UCS2; this receiver uses UCS4. Install the py27ucs4 package.')
from ._entry import (Plugins as _native_Plugins, main as _native_main,
                     menu as _native_menu, sessionstart as _native_sessionstart, get_controller)


# Receiver menus inspect these callbacks; keep their signatures as Python functions.
def main(session, **kwargs):
    return _native_main(session, **kwargs)


def sessionstart(reason, session=None, **kwargs):
    return _native_sessionstart(reason, session=session, **kwargs)


def _public_callback(callback):
    if callback is _native_main:
        return main
    if callback is _native_menu:
        return menu
    if callback is _native_sessionstart:
        return sessionstart
    return callback


def menu(menuid, **kwargs):
    entries = _native_menu(menuid, **kwargs)
    return [(entry[0], _public_callback(entry[1])) + tuple(entry[2:]) for entry in entries]


def Plugins(**kwargs):
    descriptors = _native_Plugins(**kwargs)
    for descriptor in descriptors:
        # DreamOS stores the callback directly as __call__; other images use fnc.
        for attribute in ('fnc', '__call__'):
            callback = getattr(descriptor, attribute, None)
            public = _public_callback(callback)
            if public is not callback:
                setattr(descriptor, attribute, public)
    return descriptors
