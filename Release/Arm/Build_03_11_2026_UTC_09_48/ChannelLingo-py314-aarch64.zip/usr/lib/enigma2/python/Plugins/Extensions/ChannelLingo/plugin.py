# -*- coding: utf-8 -*-
# ChannelLingo by iet5. Native distribution entry point.
import platform as _platform
import struct as _struct
import sys as _sys
if _sys.version_info[:2] != (3, 14):
    raise ImportError('ChannelLingo requires CPython 3.14; install the matching build.')
if getattr(_sys, 'abiflags', '') or hasattr(_sys, 'gettotalrefcount'):
    raise ImportError('ChannelLingo requires a standard, GIL-enabled release Python build.')
_machine, _bits = _platform.machine().lower(), _struct.calcsize('P') * 8
if _machine not in ('aarch64', 'arm64') or _bits != 64:
    # Say what was found: "wrong architecture" alone does not tell a 64-bit receiver from a 32-bit one.
    raise ImportError('ChannelLingo: wrong receiver architecture (this receiver: %s, %d-bit Python; this build is for '
                      'aarch64, 64-bit); install the matching build.' % (_machine, _bits))
from ._entry import Plugins, main, menu, sessionstart, get_controller
