#!/bin/sh
# ChannelLingo by iet5 - installer of the universal package.
# It finds which Python Enigma2 runs and on which processor, takes the build that matches from this folder and installs
# it exactly as the single package of that build would be. Nothing outside the plugin folder is changed (your keys and
# settings in /etc/enigma2 stay); the old plugin folder is kept in /home/root.
#
#   sh install.sh            install the build that matches this receiver
#   sh install.sh --check    only say which build would be installed
#
# Tests only: CHANNELLINGO_ROOT=<folder> installs under <folder> instead of /, CHANNELLINGO_PYTHON=<interpreter> names the
# interpreter to ask, CHANNELLINGO_VARIANT=<name> forces a build.
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=${CHANNELLINGO_ROOT:-}
CHECK=0
[ "${1:-}" = "--check" ] && CHECK=1

say() { printf '%s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

# Read the running Enigma2 process first, otherwise its ELF dependencies. Never guess from PATH order.
find_python() {
    if [ -n "${CHANNELLINGO_PYTHON:-}" ]; then printf '%s\n' "$CHANNELLINGO_PYTHON"; return; fi
    parser=""
    for candidate in python3 python python2; do
        command -v "$candidate" >/dev/null 2>&1 || continue
        if "$candidate" -S -c 'import struct, sys' >/dev/null 2>&1; then parser=$candidate; break; fi
    done
    [ -n "$parser" ] || { say "ERROR: No working Python interpreter found." >&2; return 1; }
    required=$("$parser" -S - "$ROOT" <<'CHANNELLINGO_PYTHON_PROBE'
"""Read Enigma2's Python requirements without importing Enigma2 (Python 2.7/3.x)."""
from __future__ import print_function
import os
import re
import struct
import sys

LIBRARY = re.compile(r'^libpython([0-9]+\.[0-9]+)([a-z]*)\.so(?:\.[0-9]+)*$')


def elf_info(path):
    with open(path, 'rb') as handle:
        data = handle.read(64 * 1024 * 1024 + 1)
    if len(data) > 64 * 1024 * 1024 or data[:4] != b'\x7fELF':
        raise ValueError('Enigma2 is not a readable supported ELF executable')
    elf_class, byte_order = struct.unpack('BB', data[4:6])
    if elf_class not in (1, 2) or byte_order not in (1, 2):
        raise ValueError('Invalid Enigma2 ELF header')
    order = '<' if byte_order == 1 else '>'
    header_format = order + ('HHIIIIIHHHHHH' if elf_class == 1 else 'HHIQQQIHHHHHH')
    header = struct.unpack_from(header_format, data, 16)
    phoff, entry_size, count = header[4], header[8], header[9]
    ph_format = order + ('IIIIIIII' if elf_class == 1 else 'IIQQQQQQ')
    if entry_size < struct.calcsize(ph_format) or count > 4096:
        raise ValueError('Invalid Enigma2 program headers')
    loads, dynamic = [], None
    for index in range(count):
        ph = struct.unpack_from(ph_format, data, phoff + index * entry_size)
        kind = ph[0]
        offset, address, size = (ph[1], ph[2], ph[4]) if elf_class == 1 else (ph[2], ph[3], ph[5])
        if offset + size > len(data):
            raise ValueError('Truncated Enigma2 ELF segment')
        if kind == 1:
            loads.append((offset, address, size))
        elif kind == 2:
            dynamic = (offset, size)
    needed, strings, strings_size = [], None, None
    if dynamic:
        fmt = order + ('iI' if elf_class == 1 else 'qQ')
        for offset in range(dynamic[0], sum(dynamic), struct.calcsize(fmt)):
            tag, value = struct.unpack_from(fmt, data, offset)
            if tag == 0:
                break
            if tag == 1:
                needed.append(value)
            elif tag == 5:
                strings = value
            elif tag == 10:
                strings_size = value
    libraries = []
    if needed:
        for offset, address, size in loads:
            if strings is not None and address <= strings < address + size:
                base = offset + strings - address
                limit = min(offset + size, base + strings_size) if strings_size else offset + size
                for index in needed:
                    end = data.find(b'\0', base + index, limit)
                    if base + index >= limit or end < 0:
                        raise ValueError('Invalid Enigma2 library table')
                    libraries.append(data[base + index:end].decode('ascii'))
                break
        else:
            raise ValueError('Enigma2 library table is missing')
    return elf_class * 32, libraries


def unicode_width(paths):
    widths = set()
    for path in paths:
        try:
            with open(path, 'rb') as handle:
                data = handle.read(32 * 1024 * 1024)
            for width in ('2', '4'):
                if ('PyUnicodeUCS' + width + '_DecodeUTF8\0').encode('ascii') in data:
                    widths.add('ucs' + width)
        except (IOError, OSError):
            continue
    if len(widths) > 1:
        raise ValueError('Conflicting Python 2.7 Unicode ABIs; nothing was installed')
    return next(iter(widths)) if widths else 'unknown'


def requirements(root):
    proc = root + '/proc'
    observations = []
    for pid in sorted(os.listdir(proc)) if os.path.isdir(proc) else []:
        if not pid.isdigit():
            continue
        process = proc + '/' + pid
        try:
            with open(process + '/comm') as handle:
                if handle.read().strip() != 'enigma2':
                    continue
            with open(process + '/maps') as handle:
                maps = handle.read()
        except (IOError, OSError):
            continue
        bits, linked = elf_info(process + '/exe')
        mapped = re.findall(r'(/[^\n]*?/libpython[0-9]+\.[0-9]+[a-z]*\.so(?:\.[0-9]+)*)(?:\s|$)', maps)
        libraries = mapped or linked
        paths = [process + '/root' + p for p in mapped] + [root + p for p in mapped]
        observations.append((bits, libraries, paths))
    if not observations:
        bits, libraries = elf_info(root + '/usr/bin/enigma2')
        paths = []
        for library in libraries:
            if LIBRARY.match(library):
                for directory in ('/lib', '/usr/lib'):
                    paths.append(root + directory + '/' + library)
                    # The multiarch subdirectory (e.g. /usr/lib/aarch64-linux-gnu) without glob, which some
                    # receiver images do not ship as a standard library (split, feed-based Python installs).
                    base = root + directory
                    try:
                        children = os.listdir(base)
                    except OSError:
                        children = []
                    for child in children:
                        paths.append(base + '/' + child + '/' + library)
        observations.append((bits, libraries, paths))
    found = set()
    for bits, libraries, paths in observations:
        matching = [LIBRARY.match(os.path.basename(p)) for p in libraries]
        matching = [m for m in matching if m is not None]
        if not matching:
            raise ValueError('Cannot identify the Python library used by Enigma2')
        for match in matching:
            if match.group(2):
                raise ValueError('Enigma2 uses an unsupported debug/free-threaded Python ABI')
            version = match.group(1)
            width = unicode_width(paths) if version == '2.7' else '-'
            found.add((version, bits, width))
    if len(found) != 1:
        raise ValueError('Conflicting Enigma2 Python requirements; nothing was installed')
    return next(iter(found))


if __name__ == '__main__':
    try:
        version, bits, width = requirements(sys.argv[1])
        print('%s/%d/%s' % (version, bits, width))
    except Exception as error:
        sys.stderr.write('ERROR: Cannot determine Enigma2 Python: %s\n' % error)
        sys.exit(1)
CHANNELLINGO_PYTHON_PROBE
    ) || return 1
    want=${required%%/*}
    rest=${required#*/}; want_bits=${rest%%/*}; want_unicode=${rest#*/}
    chosen=""; chosen_abi=""
    for candidate in "python$want" python3 python python2; do
        command -v "$candidate" >/dev/null 2>&1 || continue
        abi=$("$candidate" -S -c 'import struct, sys
print("%d.%d/%d/%s/%s" % (sys.version_info[0], sys.version_info[1], struct.calcsize("P") * 8,
    ("ucs2" if sys.maxunicode == 65535 else "ucs4") if sys.version_info[0] == 2 else "-",
    getattr(sys, "abiflags", "") or ("debug" if hasattr(sys, "gettotalrefcount") else "")))' 2>/dev/null) || continue
        have=${abi%%/*}; rest=${abi#*/}; have_bits=${rest%%/*}; rest=${rest#*/}
        have_unicode=${rest%%/*}; flags=${rest#*/}
        [ "$have" = "$want" ] && [ "$have_bits" = "$want_bits" ] && [ -z "$flags" ] || continue
        [ "$want_unicode" = unknown ] || [ "$have_unicode" = "$want_unicode" ] || continue
        if [ -n "$chosen_abi" ] && [ "$chosen_abi" != "$abi" ]; then
            say "ERROR: Multiple incompatible Python interpreters match Enigma2; nothing was installed." >&2
            return 1
        fi
        [ -n "$chosen" ] || chosen=$candidate
        chosen_abi=$abi
    done
    [ -n "$chosen" ] || {
        say "ERROR: Enigma2 requires Python $want, $want_bits-bit ($want_unicode); no matching interpreter found." >&2
        return 1
    }
    printf '%s\n' "$chosen"
}

PY=$(find_python) || die "Python detection failed; nothing was installed."
[ -n "$PY" ] || die "no Python found on this receiver"
FACTS=$("$PY" -S -c 'import platform, struct, sys
print("version=%d.%d" % sys.version_info[:2])
print("bits=%d" % (struct.calcsize("P") * 8))
print("machine=%s" % platform.machine().lower())
print("unicode=%s" % ("ucs2" if sys.maxunicode == 65535 else "ucs4"))' 2>/dev/null) || die "cannot run $PY"
fact() { printf '%s\n' "$FACTS" | sed -n "s/^$1=//p" | head -n 1; }
VER=$(fact version); BITS=$(fact bits); MACHINE=$(fact machine); UNI=$(fact unicode)
[ -n "$VER" ] && [ -n "$BITS" ] && [ -n "$MACHINE" ] || die "could not read the facts of $PY"
case "$VER" in 3.*) UNI="-" ;; esac
say "This receiver: Python $VER ($UNI), ${BITS}-bit, processor $MACHINE."

# ARM and (where this package has it) 32-bit MIPS. A 32-bit Python on a 64-bit ARM kernel may report armv8l or
# aarch64: the pointer size tells it from a real 64-bit one.
case "$BITS:$MACHINE" in
    32:armv7l|32:armv7|32:arm|32:armv8l|32:aarch64|32:arm64) ARCH=armv7l ;;
    64:aarch64|64:arm64) ARCH=aarch64 ;;
    32:mipsel|32:mips) ARCH=mipsel ;;
    *) die "this processor ($MACHINE, ${BITS}-bit Python) is not one this package is built for (ARM 32-bit and 64-bit, MIPS 32-bit little-endian)." ;;
esac

VARIANT=${CHANNELLINGO_VARIANT:-}
if [ -z "$VARIANT" ]; then
    case "$VER/$BITS/$UNI/$ARCH" in
        2.7/32/ucs2/armv7l) VARIANT=py27-dm ;;
        2.7/64/ucs2/aarch64) VARIANT=py27ucs2-aarch64 ;;
        2.7/64/ucs4/aarch64) VARIANT=py27ucs4-aarch64 ;;
        2.7/32/ucs4/armv7l) VARIANT=py27ucs4-armv7l ;;
        3.14/64/-/aarch64) VARIANT=py314-aarch64 ;;
        3.14/32/-/armv7l) VARIANT=py314-dm ;;
        *) VARIANT="" ;;
    esac
fi
if [ -z "$VARIANT" ] || [ ! -d "$HERE/variants/$VARIANT" ]; then
    say "No build in this package for Python $VER ($UNI), ${BITS}-bit. The builds here:"
    for found in "$HERE"/variants/*; do say "  $(basename "$found")"; done
    die "nothing was installed."
fi
say "Build chosen: $VARIANT"
[ "$CHECK" = "1" ] && { say "(--check: nothing was installed.)"; exit 0; }

EXT="$ROOT/usr/lib/enigma2/python/Plugins/Extensions"
PLUGIN="$EXT/ChannelLingo"
SHARED="$HERE/resources/usr/lib/enigma2/python/Plugins/Extensions/ChannelLingo"
OWN="$HERE/variants/$VARIANT/usr/lib/enigma2/python/Plugins/Extensions/ChannelLingo"
[ -d "$SHARED" ] && [ -d "$OWN" ] || die "this package is incomplete (a folder is missing)."

# The files must be what the builder wrote: a bad copy to the receiver is found here, not by Enigma2.
if command -v sha256sum >/dev/null 2>&1 && [ -r "$HERE/SHA256SUMS" ]; then
    LIST="${TMPDIR:-/tmp}/channellingo-sums-$$"
    grep -e ' resources/' -e " variants/$VARIANT/" "$HERE/SHA256SUMS" > "$LIST"
    (cd "$HERE" && sha256sum -c "$LIST" >/dev/null 2>&1) || { rm -f "$LIST"; die "a file of this package is damaged or missing: copy the package again."; }
    rm -f "$LIST"
    say "Files checked."
else
    say "(sha256sum not available: the files were not checked.)"
fi

mkdir -p "$EXT" || die "cannot write $EXT"
STAGE="$EXT/.channellingo-stage-$$"
rm -rf "$STAGE"
mkdir -p "$STAGE" || die "cannot write $STAGE"
cp -R "$SHARED/." "$STAGE/" && cp -R "$OWN/." "$STAGE/" || { rm -rf "$STAGE"; die "could not copy the files."; }
[ -f "$STAGE/plugin.py" ] && [ -f "$STAGE/ver.txt" ] || { rm -rf "$STAGE"; die "the installed copy is incomplete."; }

BACKUP=""
BACKUP_DIR=""
INSTALLED=0
cleanup_install() {
    result=$?
    trap - EXIT HUP INT TERM
    if [ "$INSTALLED" != 1 ] && [ -n "$BACKUP" ] && [ ! -e "$PLUGIN" ] && [ ! -L "$PLUGIN" ]; then
        if mv "$BACKUP" "$PLUGIN"; then
            say "Installation failed; the previous ChannelLingo was restored."
            rmdir "$BACKUP_DIR" 2>/dev/null || :
        else
            say "ERROR: Cannot restore the previous plugin. Its backup is kept in $BACKUP"
            result=1
        fi
    fi
    [ ! -d "$STAGE" ] || rm -rf "$STAGE"
    exit "$result"
}
trap cleanup_install EXIT
trap 'exit 1' HUP INT TERM
NEW_VERSION=$(sed -n '1p' "$STAGE/ver.txt" 2>/dev/null)
if [ -e "$PLUGIN" ] || [ -L "$PLUGIN" ]; then
    OLD_VERSION=$(sed -n '1p' "$PLUGIN/ver.txt" 2>/dev/null)
    say "Previous ChannelLingo detected: ${OLD_VERSION:-unknown version}."
    say "Removing its files from the active plugin folder before installing ${NEW_VERSION:-the new version}."
    mkdir -p "$ROOT/home/root" || die "cannot create a backup folder; the previous plugin was not removed."
    BACKUP_DIR=$(mktemp -d "$ROOT/home/root/ChannelLingo.backup-XXXXXX") || die "cannot create a unique backup; the previous plugin was not removed."
    BACKUP="$BACKUP_DIR/ChannelLingo"
    if ! mv "$PLUGIN" "$BACKUP"; then
        BACKUP=""
        rmdir "$BACKUP_DIR" 2>/dev/null || :
        die "cannot remove the previous plugin from the active folder."
    fi
else
    say "No previous ChannelLingo installation found. Installing ${NEW_VERSION:-the new version}."
fi
mv "$STAGE" "$PLUGIN" || die "could not put the new plugin in place."
INSTALLED=1
say "Installed: $VARIANT -> $PLUGIN"
[ -z "$BACKUP" ] || say "Previous version backup: $BACKUP"
say "Settings and API keys were kept."
say "Now restart Enigma2 (or restart the receiver)."
