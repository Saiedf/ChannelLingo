# -*- coding: utf-8 -*-
# ChannelLingo by iet5. Native distribution entry point.
import platform as _platform
import struct as _struct
import sys as _sys
if _sys.version_info[:2] != (2, 7):
    raise ImportError('ChannelLingo requires CPython 2.7; install the matching build.')
if getattr(_sys, 'abiflags', '') or hasattr(_sys, 'gettotalrefcount'):
    raise ImportError('ChannelLingo requires a standard, GIL-enabled release Python build.')
_machine, _bits = _platform.machine().lower(), _struct.calcsize('P') * 8
if _machine not in ('armv7l', 'armv7', 'arm', 'armv8l', 'aarch64', 'arm64') or _bits != 32:
    # Say what was found: "wrong architecture" alone does not tell a 64-bit receiver from a 32-bit one.
    raise ImportError('ChannelLingo: wrong receiver architecture (this receiver: %s, %d-bit Python; this build is for '
                      'armv7l, 32-bit); install the matching build.' % (_machine, _bits))
if _sys.maxunicode != 1114111:
    raise ImportError('ChannelLingo requires Python 2.7 UCS4; this receiver uses UCS2. Install the py27ucs2 package.')
from ._entry import Plugins, main, menu, sessionstart, get_controller
